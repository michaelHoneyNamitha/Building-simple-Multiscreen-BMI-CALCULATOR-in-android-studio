package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);

        //get value from screen1
        Intent i=getIntent();
        double result=i.getExtras().getDouble("BMI");

        //Bmi and result textview
        TextView bmiLabel = findViewById(R.id.getBmi);
        TextView resultLabel = findViewById(R.id.getResult);

        //to output the result
        String output="";

        if (result < 18.5) {
            output = "Underweight";
        }
        else if (result >= 18.5 && result <= 24.9) {
            output= "Normalweight";
        }
        else if (result >= 25 && result <= 29.9) {
            output = "Overweight";
        }
        else if (result > 30) {
            output = "Obesity";
        }
        // output result to screen2
        bmiLabel.setText(String.format("%.2f",result));
        resultLabel.setText(output);
    }
}