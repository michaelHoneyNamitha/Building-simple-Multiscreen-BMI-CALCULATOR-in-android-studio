package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void calculateBmi(View v){
        //get the user input by its id
        EditText m= (EditText) findViewById(R.id.getMass);
        EditText h = (EditText) findViewById(R.id.getHeight);
        TextView txt = (TextView) findViewById(R.id.result);
        //calculating mass and height
        double mass = Double.valueOf(m.getText().toString());
        double height = Double.valueOf(h.getText().toString());
        double bmi=(mass/(height*height));
        txt.setText(String.format("%.2f", bmi));
        //to clear the input from field once the bmi is calculated
        m.setText("");
        h.setText("");
        //send the calculated BMI to screen 2
        Intent i=new Intent(this,Screen2.class);
        i.putExtra("BMI",bmi);
        startActivity(i);

    }
}